# SocialSave — Cloudflare Pages Edition

Modern responsive frontend + Cloudflare Pages Functions. No VPS required.

## IMPORTANT LIMITATIONS
- Supports only **direct HTTPS video file URLs** on domains you own or are authorized to use.
- DOES NOT extract TikTok, Instagram, Facebook, YouTube page URLs; does not run yt-dlp or FFmpeg.
- Does not bypass DRM, authentication, access controls, or website restrictions.
- Backend blocks redirects and unapproved hosts; configure the same `allowedHosts` in BOTH `functions/api/info.js` and `functions/api/download.js`.
- Direct URLs must respond to HEAD with `Content-Type: video/*`.
- 100 MB limit is best-effort when upstream provides Content-Length. Production deployment should use stronger quotas, streaming size enforcement, abuse controls, and Cloudflare plan limits. For safer use, configure Cloudflare Access or other authorization if not intended as public service.

## Deploy with Wrangler (recommended)

1. Install Node.js 20+ locally.
2. Edit both `functions/api/info.js` and `functions/api/download.js`, replace `cdn.example.com` with a domain you own/control that hosts video files. This is an exact hostname allowlist.
3. From the project root, run:

```bash
npx wrangler login
npx wrangler pages deploy public --project-name YOUR_EXISTING_PAGES_PROJECT
```

Run from the root directory where `functions/` and `public/` are siblings. Check Cloudflare Pages docs for your deployment setup. Dashboard drag-and-drop upload does NOT deploy Pages Functions. Git integration is also supported.

4. Check `/api/info` with a POST request. A GET in the browser is not a valid test of the POST endpoint.

```bash
curl -i -X POST https://YOUR_DOMAIN/api/info -H 'Content-Type: application/json' -d '{"url":"https://YOUR_ALLOWED_HOST/video.mp4"}'
```

5. If Cloudflare project is already linked to x.xpocks.web.id, its custom domain remains configured on the project.

## Project structure

```
public/index.html
public/style.css
public/app.js
functions/api/info.js
functions/api/download.js
```

## Note

The application does not claim universal social media support. Respect copyright, platform terms, and Cloudflare bandwidth/usage policies.
