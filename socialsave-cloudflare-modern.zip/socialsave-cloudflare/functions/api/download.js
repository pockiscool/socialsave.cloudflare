const allowedHosts=['cdn.example.com']; // REPLACE with your controlled media host(s)
export async function onRequestGet({request}){
 let url;try{url=new URL(new URL(request.url).searchParams.get('url'))}catch{return new Response('URL tidak valid',{status:400})}
 if(url.protocol!=='https:'||url.username||url.password||url.port||!allowedHosts.includes(url.hostname.toLowerCase()))return new Response('Host tidak diizinkan',{status:403});
 try{
  const upstream=await fetch(url.toString(),{redirect:'manual',signal:AbortSignal.timeout(25000)});
  if(!upstream.ok)return new Response('Video tidak tersedia',{status:502});
  const type=upstream.headers.get('content-type')||'';
  if(!type.toLowerCase().startsWith('video/'))return new Response('Bukan video',{status:415});
  const len=Number(upstream.headers.get('content-length')||0);
  if(len>100*1024*1024)return new Response('File terlalu besar',{status:413});
  const filename=(url.pathname.split('/').pop()||'video.mp4').replace(/[^a-zA-Z0-9._-]/g,'_').slice(0,100);
  const headers=new Headers({'Content-Type':type,'Content-Disposition':`attachment; filename="${filename}"`,'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'});
  if(len)headers.set('Content-Length',String(len));
  return new Response(upstream.body,{headers});
 }catch{return new Response('Gagal mengakses video',{status:502})}
}
