const allowedHosts = ['cdn.example.com']; // REPLACE with domains you own/control
function json(data,status=200){return Response.json(data,{status,headers:{'Cache-Control':'no-store'}})}
function validate(value){let u;try{u=new URL(value)}catch{return null}if(u.protocol!=='https:'||u.username||u.password||u.port||!allowedHosts.includes(u.hostname.toLowerCase()))return null;return u}
export async function onRequestPost({request}){
  let body;try{body=await request.json()}catch{return json({error:'JSON tidak valid'},400)}
  const url=validate(body?.url);if(!url)return json({error:'Hanya URL HTTPS file video dari domain yang Anda izinkan. Atur allowedHosts di functions/api/info.js.'},400);
  try{
    const res=await fetch(url.toString(),{method:'HEAD',redirect:'manual',signal:AbortSignal.timeout(12000)});
    if(!res.ok)return json({error:`Sumber mengembalikan HTTP ${res.status}`},422);
    const type=res.headers.get('content-type')||'';
    if(!type.toLowerCase().startsWith('video/'))return json({error:'URL bukan file video langsung (Content-Type video/*).'},422);
    const length=Number(res.headers.get('content-length')||0);
    if(length>100*1024*1024)return json({error:'File lebih dari batas 100 MB.'},413);
    return json({title:decodeURIComponent(url.pathname.split('/').pop()||'Video'),type,size:length||null,downloadUrl:'/api/download?url='+encodeURIComponent(url.toString())});
  }catch{return json({error:'Tidak dapat membaca metadata. Server sumber mungkin menolak HEAD.'},502)}
}
